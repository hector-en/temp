# Smoke Report

| Field | Value |
|---|---|
| Phase | skeleton-progress |
| Timestamp UTC | 20260626T193435Z |
| Workspace | /workspace |
| Module glob | /workspace/tests/smoke.d/*.smoke.sh |
| Batch slug | 01-runtime-substrate |
| Strict mode | 0 |

## Module Results

| Module | Status | Detail |
|---|---|---|
| 10-core-layout.smoke.sh | PASS | PASS: core layout paths are present and Batch 01 runtime substrate contracts passed offline checks |
| 20-python-package.smoke.sh | SKIP | SKIP: no Python package markers found under /workspace |
| 30-skeleton-evidence.smoke.sh | PASS | PASS: skeleton evidence paths are present for 01-runtime-substrate |
| 40-organ-evidence.smoke.sh | SKIP | SKIP: organ evidence checks are not applicable for phase skeleton-progress |
| 50-config-boundary.smoke.sh | PASS | PASS: config boundary paths are present and were not modified by this smoke module |
| 60-infra-tools.smoke.sh | WARN | WARN: available infra tools: kubectl; missing: docker terraform runpod |
| 70-grn-contract.smoke.sh | SKIP | SKIP: no GRN contract artifacts found under /workspace |
| 90-research-assistant.smoke.sh | WARN | WARN: research-assistant helper is offline-safe and passed, but endpoint env vars are not fully configured OpenCode config paths are absent |

## Overall

| Field | Value |
|---|---|
| Overall status | WARN |
| Report path | /workspace/runs/smoke/20260626T193435Z-skeleton-progress/SMOKE_REPORT.md |

Role owner: smoke/dynamic-smoke
Workspace root: /workspace
Commands to expose: none
Config integration needed: no
Suggested integration type: none / smoke-only
Smoke check: BATCH_SLUG="01-runtime-substrate" bash /workspace/scripts/smoke.sh skeleton-progress
Output contract: Batch 01 smoke modules preserve DYN-SMOKE v2 direct PASS/WARN/SKIP/FAIL contract
Safety boundaries: local-only, no provider calls, no secrets, no infra mutation
Open questions for operator-side integration: none

Role owner: operator/config for /workspace roots and runtime checks; aiengineer for /workspace/repos/research-assistant
Workspace root: /workspace; /workspace/repos/research-assistant
Commands to expose:
- python3 /workspace/scripts/runtime_checks/check_runpod_workspace.py
- python3 /workspace/scripts/runtime_checks/check_gpu_runtime.py
- python3 /workspace/scripts/runtime_checks/check_cuda_torch_runtime.py
- python3 /workspace/scripts/runtime_checks/check_docker_gpu_access.py
- python3 /workspace/scripts/runtime_checks/check_kubernetes_context.py
- python3 /workspace/repos/research-assistant/smoke_test.py
Python packages needed: standard library only
Config integration needed: deferred; likely workspace-root plus health-check or launcher exposure if operator approves
Smoke check:
- BATCH_SLUG="01-runtime-substrate" bash /workspace/scripts/smoke.sh skeleton-progress
- python3 /workspace/repos/research-assistant/smoke_test.py
Output contract:
- Generic runtime roots under /workspace
- Runtime policy files under /workspace/runtime
- Safe readiness reports under /workspace/scripts/runtime_checks
- Dummy remote model client/router response under /workspace/repos/research-assistant
Operator/config notes:
- Do not edit config internals in this implementation batch.
- Later operator-side work can decide bootstrap/profile/alias exposure.
- `python3` is the available interpreter in this environment.
- `PYTHONPYCACHEPREFIX=/tmp` may be useful for operator-side compile validations when /workspace is not writable for __pycache__.

# agentfield-grn-private real-v0 bundle

Private project data bundle for `infractl` real-v0. This mirrors the real repo layout seen in the uploaded private codebase inventory.

This bundle supports two modes:

1. **webchat fallback mode**: use copied files under `sources/`.
2. **workspace validation mode**: use `files.yaml` `real_path` entries against your actual repo root.

Do not push this bundle to a public repo.

Use `CLI_EXTRACTION_NOTES.md` through Batch 04. After Batch 04, promote repeated patterns into v1 schemas/templates/commands.

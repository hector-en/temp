# BATCH_CREATION_ANX04_workflow_smoke_automation

Status: batch-creation hook for `NEW_CHAT_PROMPT_batch_creation.md`.  
Purpose: make `SPEC_Layer01_01-runtime-substrate-ANX04_workflow_smoke_automation.md` consumable by future skeleton and organ batch-generation chats.

## Canonical annex file to request

When the selected batch needs this context, ask the user to upload:

```text
SPEC_Layer01_01-runtime-substrate-ANX04_workflow_smoke_automation.md
```

## What this hook represents

This hook keeps the batch-generation prompt clean while making the day-to-day workflow and smoke-module decision rules hard to miss.

The deeper annex captures how generated Codex batches should preserve:

```text
POSTCHECK.md
INTEGRATION_REQUEST.md
smoke report path
PASS / SKIP / accepted WARN gate
local-vs-global smoke decision
no config edits during skeleton/organ implementation
organ workflow parity where relevant
```

This hook does not create a new product batch. It attaches an operational guardrail to every generated batch so that batch creation remembers what happens after implementation: evidence, dynamic smoke, smoke-module update decision, classification, companion timing, and later config integration.

## Batch request rule

| Selected skeleton batch | Ask user to supply the annex? | Batch-creation behavior |
|---:|---|---|
| 01 `01-runtime-substrate` | yes, required | Stop and ask for the annex if missing. Batch 01 establishes the runtime/smoke/evidence root contracts that later batches depend on. |
| 02 `02-research-workspace` | yes, required | Stop and ask for the annex if missing. Batch 02 is the first project-domain workspace and must preserve POSTCHECK / INTEGRATION_REQUEST / smoke gating plus local/global smoke decisions. |
| 03-05 Layer 2 setup batches | yes, required | Stop and ask for the annex if missing. These batches create role, PKM, and publisher surfaces whose smoke coverage and companion timing must be explicit. |
| 06-13 Layer 3 research/run batches | yes, required | Stop and ask for the annex if missing. Research, search, local smoke, and RunPod dry-run batches are especially likely to create local smoke routines or update domain smoke modules. |
| 14-15 Layer 4 reasoning batches | yes, required | Stop and ask for the annex if missing. OpenClaw/PKM reasoning batches must preserve no-live-call, selected-context, smoke, and companion guardrails. |
| 16-24 Layer 5 orchestration batches | yes, required | Stop and ask for the annex if missing. Agentfield, Paperclip, and campaign batches must preserve guarded live boundaries and smoke coverage decisions. |

## Real-organ mirror rule

| Organ batch | Ask user to supply the annex? | Behavior |
|---:|---|---|
| R01 `real-contract-audit-runtime-role-readiness` | yes, required | Needed to preserve skeleton evidence, smoke, and contract-audit gates before real organs replace dummy internals. |
| R02-R06 research organ batches | yes, required | Needed to preserve local smoke, global `70-grn-contract` / possible search contract, output-contract, and no-live-run decisions. |
| R07 `real-runpod-boundary` | yes, required | Needed to preserve guarded RunPod dry-run-to-live boundary and avoid accidental live infrastructure actions. |
| R08-R11 platform organ batches | yes, required | Needed to preserve OpenClaw, Agentfield, Paperclip, campaign, review, and guarded-live smoke decisions. |
| R12 end-to-end real local smoke | yes, required | Needed to preserve end-to-end no-live smoke gating and final classification rules. |

## How generated batch files should consume it

### Every skeleton batch

Add the annex to `PROJECT_CACHE.md` as a required read-only input. The generated `SPEC.md` and `RUN_INSTRUCTIONS.md` should include a compact workflow checklist:

```text
After implementation, Codex must write POSTCHECK.md and INTEGRATION_REQUEST.md under /mnt/egress/dev-recordings/skeleton/<batch-slug>/.
Then a separate smoke execution step must run the active dynamic smoke runner for skeleton-progress.
Do not start the next batch until smoke has PASS, SKIP, or accepted documented WARN.
Do not edit config/lv/workflow during skeleton implementation.
Decide whether the batch creates/updates a local smoke routine or changes a domain contract requiring a global smoke.d update.
Do not create one global smoke module per batch.
```

### Every organ batch

Add the annex to `PROJECT_CACHE.md` as a required read-only input. The generated organ `SPEC.md` and `RUN_INSTRUCTIONS.md` should include the organ parity checklist:

```text
After implementation, Codex must write POSTCHECK.md and INTEGRATION_REQUEST.md under /mnt/egress/organs/dev-recordings/organs/<batch-slug>/.
Then a separate smoke execution step must run the active dynamic smoke runner for organ-progress.
Do not start the next organ batch until smoke has PASS, SKIP, or accepted documented WARN and the relevant skeleton output contract is preserved.
Do not run live providers, live RunPod, Paperclip writes, Agentfield live execution, Kubernetes mutation, or Terraform mutation unless explicitly approved by the organ batch.
```

## Stop condition language for batch-generation chats

For required skeleton or organ batches, if the annex is missing, respond:

```text
Missing required workflow/smoke automation annex for this batch:
- SPEC_Layer01_01-runtime-substrate-ANX04_workflow_smoke_automation.md

Please upload it before I generate the Codex batch package, because this batch must preserve the day-to-day evidence, smoke, local/global smoke-module decision, and stop/continue gates.
```

## Guardrail

This hook does not change the corrected skeleton or real-organ batch slicing. It is contextual workflow guidance only. It must not embed the full workflow files, the full smoke update tables, or the deep annex content into `NEW_CHAT_PROMPT_batch_creation.md`.

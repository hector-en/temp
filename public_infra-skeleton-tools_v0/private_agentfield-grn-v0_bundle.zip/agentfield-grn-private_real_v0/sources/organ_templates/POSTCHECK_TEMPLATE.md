# Placeholder for real-workspace source

This file is listed in the uploaded private codebase inventory, but the actual file content was not mounted in this webchat bundle. In workspace mode, validate it at its real repo path before using it.

Relative source key: `sources/organ_templates/POSTCHECK_TEMPLATE.md`

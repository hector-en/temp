# Update Workflow — Already-Run Skeleton/Organ Batch Delta Updates

This workflow defines how to update batches that have already been implemented when a new hook, annex, smoke rule, evidence rule, workflow rule, or contract clarification appears later.

It complements, but does not replace:

```text
day_to_day_skeleton_run.md
day_to_day_organs_run.md
final_workflow.md
smoke_module_update_workflow.md
NEW_CHAT_PROMPT_batch_creation.md
NEW_CHAT_PROMPT_batch_update.md
```

## 1. Purpose

Normal batch creation handles a batch before implementation. Update workflow handles a batch after it has already run.

```text
Creation workflow:
  create one fresh Codex implementation batch for not-yet-run work.

Update workflow:
  create one small Codex delta pack for already-run work.
```

The update workflow exists so the platform can safely retrofit earlier batches with new operational rules without pretending they were never run.

Examples:

```text
A new smoke/evidence automation hook is introduced after Batch 01 already ran.
A later annex clarifies that an old batch needs a local smoke routine.
A smoke report path is missing from historical evidence.
A companion/index must be updated after a checked contract changed.
A global smoke module must be split or extended because a domain surface changed.
```

## 2. Non-goals

Update workflow must not:

```text
rerun the original batch as a normal batch
regenerate the original batch zip
rewrite original POSTCHECK.md
rewrite original INTEGRATION_REQUEST.md
overwrite historical smoke reports
invent missing evidence
expand the original batch scope
edit config/lv/workflow internals unless this is an explicit config-integration milestone
perform live/cloud/provider/cluster actions by default
```

## 3. Canonical update inputs

Every update starts with four values:

```text
TARGET_TRACK=skeleton|organ
TARGET_BATCH=<01-24 or R01-R12>
TARGET_SLUG=<existing-batch-slug>
UPDATE_TOPIC=<short hook/update topic>
```

The update prompt is:

```text
NEW_CHAT_PROMPT_batch_update.md
```

The update prompt reads compact update hooks:

```text
BATCH_UPDATE_ANX*.md
```

The update hooks request deeper batch-aligned annexes:

```text
SPEC_Layer<##>_<batch-slug>-ANX<##>_<topic>.md
```

## 4. Canonical evidence paths

### Skeleton original evidence

```text
/mnt/egress/dev-recordings/skeleton/<batch-slug>/POSTCHECK.md
/mnt/egress/dev-recordings/skeleton/<batch-slug>/INTEGRATION_REQUEST.md
/workspace/runs/smoke/<timestamp-phase>/SMOKE_REPORT.md
/mnt/ingress/infra/skeleton/companion/<batch-slug>/COMPANION.md
```

### Skeleton update evidence

```text
/mnt/egress/dev-recordings/skeleton/<batch-slug>/updates/<update-id>/UPDATE_POSTCHECK.md
/mnt/egress/dev-recordings/skeleton/<batch-slug>/updates/<update-id>/UPDATE_INTEGRATION_REQUEST.md
/mnt/egress/dev-recordings/skeleton/<batch-slug>/updates/<update-id>/CHANGESET_MANIFEST.md
```

### Organ original evidence

```text
/mnt/egress/organs/dev-recordings/organs/<batch-slug>/POSTCHECK.md
/mnt/egress/organs/dev-recordings/organs/<batch-slug>/INTEGRATION_REQUEST.md
/workspace/runs/smoke/<timestamp-phase>/SMOKE_REPORT.md
/mnt/ingress/infra/organs/companion/<batch-slug>/COMPANION.md
/mnt/ingress/infra/skeleton/companion/<skeleton-slug>/COMPANION.md when relevant
```

### Organ update evidence

```text
/mnt/egress/organs/dev-recordings/organs/<batch-slug>/updates/<update-id>/UPDATE_POSTCHECK.md
/mnt/egress/organs/dev-recordings/organs/<batch-slug>/updates/<update-id>/UPDATE_INTEGRATION_REQUEST.md
/mnt/egress/organs/dev-recordings/organs/<batch-slug>/updates/<update-id>/CHANGESET_MANIFEST.md
```

## 5. Update loop

Use this loop for every already-run batch update.

```text
U-T1  User starts an update chat with NEW_CHAT_PROMPT_batch_update.md.
U-T2  ChatGPT verifies target variables and required files.
U-T3  ChatGPT reads existing batch evidence and relevant hooks/annexes.
U-T4  ChatGPT classifies the update.
U-T5  ChatGPT creates one Codex-ready update pack.
U-T6  Human/Codex stages the update pack.
U-T7  Codex applies only the listed delta tasks.
U-T8  Codex writes update evidence under updates/<update-id>/.
U-T9  Codex runs validation and, if required, dynamic smoke.
U-T10 Human/ChatGPT classifies PASS/SKIP/WARN/FAIL.
U-T11 Companion/index is updated only if the checked readable contract changed.
```

## 6. Minimum continue rule

Do not treat an update as accepted until it has:

```text
1. UPDATE_POSTCHECK.md
2. UPDATE_INTEGRATION_REQUEST.md
3. CHANGESET_MANIFEST.md
4. validation output recorded in UPDATE_POSTCHECK.md
5. smoke report path if smoke execution is part of the update
6. PASS, SKIP, or accepted documented WARN
```

For organ updates, also require:

```text
7. preserved relevant skeleton output contract
```

## 7. Update classifications

Every update has exactly one primary classification.

| Classification | Meaning | Typical action |
|---|---|---|
| `evidence-reconciliation` | Original evidence is missing or incomplete. | Create update evidence and record gaps without inventing history. |
| `smoke-run-reconciliation` | Implementation/evidence exists but smoke report is missing or stale. | Run active smoke command and record report path. |
| `local-smoke-routine-update` | A batch-owned subsystem needs a local smoke routine. | Add/update local smoke routine and optional global call path. |
| `global-smoke-module-update` | A domain contract/platform surface changed. | Update the smallest domain-owned global smoke module. |
| `runner-protocol-update` | Smoke architecture or report/phase behavior changed. | Update protocol/orchestrator only under explicit scope. |
| `instruction-contract-update` | Batch generated instructions/templates need a new rule but code stays stable. | Update instruction pack and record evidence. |
| `companion-index-update` | Readable companion/index must reflect a checked contract change. | Update companion/index after evidence/smoke. |
| `blocking-repair` | Existing implementation violates required contract. | Stop normal update and create a repair pack. |

## 8. Smoke update decision tree

Use this decision tree during U-T4 classification.

```text
Did smoke architecture, phase behavior, or report format change?
  yes -> runner-protocol-update
  no  -> continue

Did a domain-wide current-state contract change?
  yes -> global-smoke-module-update
  no  -> continue

Did a project-local CLI/schema/fixture/subsystem need a repeatable local check?
  yes -> local-smoke-routine-update
  no  -> continue

Is the only missing item a smoke report path or smoke execution record?
  yes -> smoke-run-reconciliation
  no  -> continue

Is original evidence missing or incomplete?
  yes -> evidence-reconciliation
  no  -> instruction-contract-update or companion-index-update depending on target
```

## 9. Global versus local smoke in update mode

Do not create one global smoke module per batch.

Global modules are domain-owned:

```text
/workspace/tests/smoke.d/10-core-layout.smoke.sh
/workspace/tests/smoke.d/20-python-package.smoke.sh
/workspace/tests/smoke.d/30-skeleton-evidence.smoke.sh
/workspace/tests/smoke.d/50-config-boundary.smoke.sh
/workspace/tests/smoke.d/60-infra-tools.smoke.sh
/workspace/tests/smoke.d/70-grn-contract.smoke.sh
/workspace/tests/smoke.d/75-runpod-dryrun.smoke.sh
/workspace/tests/smoke.d/80-openclaw-pkm.smoke.sh
/workspace/tests/smoke.d/82-publisher-latex.smoke.sh
/workspace/tests/smoke.d/85-agentfield.smoke.sh
/workspace/tests/smoke.d/86-paperclip-adapter.smoke.sh
/workspace/tests/smoke.d/88-agentfield-campaign.smoke.sh
/workspace/tests/smoke.d/90-research-assistant.smoke.sh
```

Local smoke routines belong to project/domain code, for example:

```text
/workspace/repos/nca-art-grn/scripts/local_smoke.sh
/workspace/repos/research-assistant/smoke_test.py
/workspace/repos/agentfield-grn/scripts/local_smoke.sh
```

A global module may call a local smoke routine, but a local routine does not replace the global module.

## 10. Smoke command patterns

Skeleton update smoke:

```bash
BATCH_SLUG="<batch-slug>" bash /workspace/scripts/smoke.sh skeleton-progress
```

If migrated:

```bash
BATCH_SLUG="<batch-slug>" bash /workspace/scripts/smoke_current_state.sh skeleton-progress
```

Organ update smoke:

```bash
BATCH_SLUG="<batch-slug>" bash /workspace/scripts/smoke.sh organ-progress
```

If migrated:

```bash
BATCH_SLUG="<batch-slug>" bash /workspace/scripts/smoke_current_state.sh organ-progress
```

The active runner must remain safe and idempotent.

## 11. Safety boundaries

All update packs must preserve these boundaries:

```text
Do not edit the config tool.
Do not edit /home/vmuser/.local/bin/config.
Do not edit /home/vmuser/.local/bin/config.sh.
Do not edit /home/vmuser/.local/lib/config-sh/installers.sh.
Do not edit /home/vmuser/.local/etc/config-sh unless this is explicitly a config-integration update.
Do not print secrets.
Do not run Terraform apply/destroy.
Do not mutate Kubernetes.
Do not launch RunPod.
Do not call live model/provider APIs.
Do not write live Paperclip data.
Do not run live Agentfield execution.
Do not run expensive experiments or training.
```

## 12. Relationship to config integration

Update workflow is still target-side project/workflow maintenance unless explicitly stated otherwise.

If an update reveals that a command, env profile, alias, health check, workflow hook, or bootstrap step should eventually become config-managed, Codex writes it into:

```text
UPDATE_INTEGRATION_REQUEST.md
```

The later vmuser/operator config-integration lane decides whether and how to edit config/lv/workflow internals.

## 13. Relationship to companion docs

Do not update companion docs simply because an update ran.

Update companion/index only when:

```text
a checked contract changed,
a new smoke/evidence rule changes operator behavior,
a readable human guide would otherwise become misleading,
or the update classification is companion-index-update.
```

The companion update must reference the update evidence path rather than rewriting original implementation history.

## 14. Naming convention

Update prompt:

```text
NEW_CHAT_PROMPT_batch_update.md
```

Update hook:

```text
BATCH_UPDATE_ANX<##>_<topic>.md
```

Deep annex:

```text
SPEC_Layer<##>_<batch-slug>-ANX<##>_<topic>.md
```

Codex update pack:

```text
codex_<target-track>_batch_update_<target-batch>_<target-slug>_<update-topic>.zip
```

Update evidence id:

```text
<YYYYMMDD>_<update-topic>
```

## 15. Example: retrofitting Batch 01 for workflow/smoke automation

Input:

```text
TARGET_TRACK=skeleton
TARGET_BATCH=01
TARGET_SLUG=01-runtime-substrate
UPDATE_TOPIC=workflow_smoke_automation
```

Read:

```text
NEW_CHAT_PROMPT_batch_update.md
update_workflow.md
BATCH_UPDATE_ANX04_workflow_smoke_automation.md
SPEC_Layer01_01-runtime-substrate-ANX04_workflow_smoke_automation.md
day_to_day_skeleton_run.md
final_workflow.md
smoke_module_update_workflow.md
existing Batch 01 POSTCHECK.md
existing Batch 01 INTEGRATION_REQUEST.md
latest Batch 01 SMOKE_REPORT.md if available
```

Output:

```text
codex_skeleton_batch_update_01_01-runtime-substrate_workflow_smoke_automation.zip
```

Codex writes:

```text
/mnt/egress/dev-recordings/skeleton/01-runtime-substrate/updates/<YYYYMMDD>_workflow_smoke_automation/UPDATE_POSTCHECK.md
/mnt/egress/dev-recordings/skeleton/01-runtime-substrate/updates/<YYYYMMDD>_workflow_smoke_automation/UPDATE_INTEGRATION_REQUEST.md
/mnt/egress/dev-recordings/skeleton/01-runtime-substrate/updates/<YYYYMMDD>_workflow_smoke_automation/CHANGESET_MANIFEST.md
```

The original Batch 01 files remain untouched unless the update pack explicitly includes a repair task and the human approves it.

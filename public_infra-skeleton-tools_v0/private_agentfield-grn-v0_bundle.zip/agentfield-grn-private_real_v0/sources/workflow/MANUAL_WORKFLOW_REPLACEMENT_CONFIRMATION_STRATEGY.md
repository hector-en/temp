# MANUAL_WORKFLOW_REPLACEMENT_CONFIRMATION_STRATEGY

Status: v0 confirmation contract before `infractl` replaces parts of the manual ChatGPT workflow.

## Goal

Use one reusable public CLI engine plus one private project data bundle.

```text
Public reusable engine:
  infra-skeleton-tools / infractl

Private project workspace data:
  agentfield-grn-private
```

The CLI does not call any LLM API. ChatGPT web remains the reasoning/writing layer. Codex remains the execution layer. `infractl` is deterministic glue.

## Manual workflow being replaced in v0

v0 replaces only stable, deterministic manual steps:

1. Remembering which files must be present for a batch/update request.
2. Checking whether project-specific sources exist.
3. Creating predictable request folders and zip files.
4. Copying selected source context into a request bundle.
5. Emitting explicit missing-file stop conditions.
6. Creating update request packs for already-run batches without overwriting old evidence.
7. Packaging ChatGPT-produced Codex files into creation/update zips.
8. Checking evidence snapshots from uploaded/copied files.
9. Keeping a project status overview from YAML plus evidence snapshots.
10. Reminding ChatGPT to update `CLI_EXTRACTION_NOTES.md` until Batch 04.

## Manual workflow not replaced in v0

v0 does not replace:

1. ChatGPT reasoning over ambiguous new knowledge.
2. Deciding whether an uploaded ANX/SPEC belongs to this batch, a future batch, global workflow, or nowhere.
3. Writing the final Codex prompt/spec/run-instruction prose.
4. Codex implementation.
5. Running smoke tests.
6. Reading real `/workspace` state.
7. Writing `/mnt/egress` evidence.
8. Live provider, RunPod, Paperclip, Agentfield, Terraform, Kubernetes, or API actions.
9. Any secret handling.

## Confirmation strategy

Before using v0 for a new batch/update, confirm:

```text
1. The public tool is loaded from infra-skeleton-tools.
2. The private project bundle is supplied separately.
3. The private bundle contains project.yaml, layers.yaml, batches.yaml, hooks.yaml, and sources/.
4. Required files are accessible.
5. Missing required files cause STOP, not invention.
6. Extra files are candidate context only.
7. ChatGPT must classify extra files before using them.
8. Request packs are not Codex execution packs.
9. Codex execution packs are created only after ChatGPT writes the expected files.
10. Evidence snapshots are snapshots only; v0 does not claim real batch execution.
```

## Profiles

```text
webchat-sandbox
  For this ChatGPT container. Writes to /mnt/data or explicit --out. Never touches /workspace or /mnt/egress.

cli-dry-run
  For a local machine. Same deterministic preview behavior. No implementation or smoke execution.

codex-pack
  For packaging ChatGPT-produced files for Codex. No workspace mutation.

workspace
  Reserved for later helper use in a real workspace. In v0, still no implementation mutation.
```

## Update-track contract

`request-update` is for already-run or partially-run batches. It must not overwrite original evidence.

Update packs must preserve this rule:

```text
Original evidence:
  /mnt/egress/dev-recordings/skeleton/<batch-slug>/POSTCHECK.md
  /mnt/egress/dev-recordings/skeleton/<batch-slug>/INTEGRATION_REQUEST.md

Update evidence:
  /mnt/egress/dev-recordings/skeleton/<batch-slug>/updates/<YYYYMMDD>_<topic>/UPDATE_POSTCHECK.md
  /mnt/egress/dev-recordings/skeleton/<batch-slug>/updates/<YYYYMMDD>_<topic>/UPDATE_INTEGRATION_REQUEST.md
  /mnt/egress/dev-recordings/skeleton/<batch-slug>/updates/<YYYYMMDD>_<topic>/CHANGESET_MANIFEST.md
```

Organ mirror:

```text
/mnt/egress/organs/dev-recordings/organs/<batch-slug>/updates/<YYYYMMDD>_<topic>/...
```

## Extra-source rule

There is no `--extra-mode` in v0.

Use only:

```bash
--extra-source PATH
```

Every extra source is candidate context. The CLI copies it into `extra_sources/` and writes `EXTRA_SOURCE_ROUTING.md`.

ChatGPT must classify whether it:

1. patches the selected batch;
2. creates/updates a SPEC annex;
3. creates/updates a hook;
4. updates future batch creation;
5. updates already-run batches;
6. updates global workflow docs;
7. is irrelevant, duplicate, or outdated;
8. requires more files before continuing.

## Organ architecture in v0

v0 is skeleton-active and organ-aware.

Skeleton Batches 01-04 are active manual workflow targets.

Organ track is scaffolded so the same CLI architecture can later support:

```bash
infractl request-create --track organ --batch R01 ...
infractl request-update --track organ --batch R01 --topic ...
```

v0 includes organ paths, organ transition source files, and an R01 scaffold entry, but it does not claim organ execution readiness.

## Batch-04 v1 gate

Until Batch 04, keep using manual ChatGPT reasoning plus request packs. At the end of each batch/update, update `CLI_EXTRACTION_NOTES.md`.

After Batch 04, use accumulated notes to decide v1 schema/template extraction.
